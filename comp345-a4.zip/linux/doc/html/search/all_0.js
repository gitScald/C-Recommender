var searchData=
[
  ['abbrevs',['abbrevs',['../class_sentence_tokenizer.html#a925161446748331a428a289e459c6e53',1,'SentenceTokenizer']]],
  ['abstracttokenizer',['AbstractTokenizer',['../class_abstract_tokenizer.html',1,'AbstractTokenizer'],['../class_abstract_tokenizer.html#ad5dd529f11552a1bb522f97077148270',1,'AbstractTokenizer::AbstractTokenizer()'],['../class_abstract_tokenizer.html#aef53a337d291e7ae1553511419d31190',1,'AbstractTokenizer::AbstractTokenizer(const std::string &amp;bad)']]]
];
