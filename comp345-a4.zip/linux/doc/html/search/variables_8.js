var searchData=
[
  ['pos_5f',['pos_',['../class_sentence.html#a9db609523d44fb91ff549e0e232d6c8e',1,'Sentence']]]
];
