var searchData=
[
  ['abbrevs',['abbrevs',['../class_sentence_tokenizer.html#a925161446748331a428a289e459c6e53',1,'SentenceTokenizer']]]
];
