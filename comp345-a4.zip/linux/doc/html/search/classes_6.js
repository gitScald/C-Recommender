var searchData=
[
  ['sentence',['Sentence',['../class_sentence.html',1,'']]],
  ['sentenceindexer',['SentenceIndexer',['../class_sentence_indexer.html',1,'']]],
  ['sentencetokenizer',['SentenceTokenizer',['../class_sentence_tokenizer.html',1,'']]],
  ['stopword',['Stopword',['../class_stopword.html',1,'']]]
];
