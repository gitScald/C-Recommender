var searchData=
[
  ['nonasciichar',['NonASCIIChar',['../struct_non_a_s_c_i_i_char.html',1,'']]]
];
