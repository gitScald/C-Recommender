var searchData=
[
  ['vec_5fpair',['vec_pair',['../class_document_indexer.html#a8a84f5e40d9364c31e81627270142628',1,'DocumentIndexer']]]
];
