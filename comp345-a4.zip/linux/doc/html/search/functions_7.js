var searchData=
[
  ['operator_20bool',['operator bool',['../class_query_result.html#a7802d975b87856e0c213575258e0f4c0',1,'QueryResult']]],
  ['operator_28_29',['operator()',['../class_document.html#a44b8141f08f57f9122b3dba4a59bf7e4',1,'Document::operator()()'],['../class_index_item.html#a38ccc46639b8d0b066024bad728c1bfa',1,'IndexItem::operator()()'],['../class_indexer.html#aa2be6d79e0425aafd10b98118fcbb4ee',1,'Indexer::operator()()'],['../class_movie.html#a2ccd49265baa8fe6c51f8f4953f20bca',1,'Movie::operator()()'],['../class_sentence.html#aacbd8da0eeadd6a544f00c7ea4169c79',1,'Sentence::operator()()'],['../class_stopword.html#a0f16e88a567b2e69f67a6c14f47d8655',1,'Stopword::operator()()']]],
  ['operator_3d',['operator=',['../class_query_result.html#a238ab498750ea7ed31b965a416cc5930',1,'QueryResult::operator=(const QueryResult &amp;qr)'],['../class_query_result.html#a61fe09a36b729072cf8db7d36fbd57ba',1,'QueryResult::operator=(QueryResult &amp;&amp;qr)']]],
  ['operator_5b_5d',['operator[]',['../class_document_indexer.html#a68178124d9e7e30a60725483300a73ee',1,'DocumentIndexer::operator[]()'],['../class_movie_indexer.html#a088b5ec171f497ca107009f9c8486c2a',1,'MovieIndexer::operator[]()'],['../class_sentence_indexer.html#adcc5897caef051a20a2ef6e767989d88',1,'SentenceIndexer::operator[]()']]]
];
