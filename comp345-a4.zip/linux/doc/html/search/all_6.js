var searchData=
[
  ['longest',['longest',['../class_document.html#ac0be9d01e5e7c2478f3857b0665789c7',1,'Document::longest()'],['../class_indexer.html#a605caf73d13945418d628d740468d86d',1,'Indexer::longest()']]]
];
