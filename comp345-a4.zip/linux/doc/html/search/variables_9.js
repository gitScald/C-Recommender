var searchData=
[
  ['release_5fdate_5f',['release_date_',['../class_movie.html#a34bde460ddda08989206136b9b07aebf',1,'Movie']]]
];
