var searchData=
[
  ['bad_5fchars',['bad_chars',['../class_abstract_tokenizer.html#a0edd17a67a3d7b9042a5817dc05ba32e',1,'AbstractTokenizer']]]
];
