var searchData=
[
  ['v_5fseparator',['v_separator',['../class_indexer.html#ab8eadc78458b58c256a70208ea927d55',1,'Indexer']]],
  ['vec_5fpair',['vec_pair',['../class_document_indexer.html#a8a84f5e40d9364c31e81627270142628',1,'DocumentIndexer']]]
];
