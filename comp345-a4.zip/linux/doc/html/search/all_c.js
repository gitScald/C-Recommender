var searchData=
[
  ['release_5fdate',['release_date',['../class_movie.html#aac8f46b332b732fa78bf19bd11b6bf8f',1,'Movie']]],
  ['release_5fdate_5f',['release_date_',['../class_movie.html#a34bde460ddda08989206136b9b07aebf',1,'Movie']]]
];
