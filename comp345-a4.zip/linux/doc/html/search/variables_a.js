var searchData=
[
  ['score_5f',['score_',['../class_query_result.html#abc28ed6816fe64438a1c4a9dcc3d802d',1,'QueryResult']]],
  ['sentences',['sentences',['../class_sentence_indexer.html#a3c6b2408388e17f3b43ec9fec36f2628',1,'SentenceIndexer']]],
  ['stopword',['stopword',['../class_indexer.html#af6f4a98f2cd0bb95f22203902ed2349d',1,'Indexer']]],
  ['stopwords',['stopwords',['../class_stopword.html#a26e651b97f51c51318f4782479f082d4',1,'Stopword']]],
  ['summary_5ffp_5f',['summary_fp_',['../class_movie_indexer.html#a0d98a6556c32ebe752e886f7c73ef790',1,'MovieIndexer']]]
];
