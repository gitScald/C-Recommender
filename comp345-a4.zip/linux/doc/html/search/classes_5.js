var searchData=
[
  ['queryresult',['QueryResult',['../class_query_result.html',1,'']]]
];
