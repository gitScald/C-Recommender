var searchData=
[
  ['pos',['pos',['../class_sentence.html#af98c9ff5c5be578e7e45057ebd9b899b',1,'Sentence']]]
];
