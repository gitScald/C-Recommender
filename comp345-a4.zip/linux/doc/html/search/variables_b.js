var searchData=
[
  ['tokenizer_5ffp',['tokenizer_fp',['../class_sentence_indexer.html#a6f6dd24962085f59f1a87e2c21edb58f',1,'SentenceIndexer']]],
  ['tokens',['tokens',['../class_abstract_tokenizer.html#a76c3d1105c591f92f1036c327acd36f3',1,'AbstractTokenizer']]]
];
