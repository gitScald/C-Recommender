var searchData=
[
  ['c_2b_2b_20movie_20recommender',['C++ Movie Recommender',['../md__c_1__users__mande__documents__git_kraken_assignment4__r_e_a_d_m_e.html',1,'']]]
];
