var searchData=
[
  ['name_5f',['name_',['../class_index.html#a66c168cae41b8ad8a683163c34772b81',1,'Index::name_()'],['../class_index_item.html#a803a48d6e32976f6c9c42e83b10f61c5',1,'IndexItem::name_()'],['../class_sentence_tokenizer.html#a7c3ce1b9636d33b34aedc21c1b9f552b',1,'SentenceTokenizer::name_()'],['../class_stopword.html#ae24bca3213b4583afe6df418020b5ce6',1,'Stopword::name_()']]],
  ['name_5fshort',['name_short',['../class_document.html#ab15ddbb4889c3ed9be0eac73f9f1db94',1,'Document']]],
  ['normalized',['normalized',['../class_indexer.html#a1345c9d490613f7b3a823ade15d7f68c',1,'Indexer']]]
];
