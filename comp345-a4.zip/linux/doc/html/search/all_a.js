var searchData=
[
  ['pos',['pos',['../class_sentence.html#af98c9ff5c5be578e7e45057ebd9b899b',1,'Sentence']]],
  ['pos_5f',['pos_',['../class_sentence.html#a9db609523d44fb91ff549e0e232d6c8e',1,'Sentence']]]
];
