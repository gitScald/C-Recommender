var searchData=
[
  ['docs',['docs',['../class_index.html#a6d6dfe2b2a058065c9e62d4f6c285a48',1,'Index']]],
  ['document',['Document',['../class_document.html#acdbcbe550084e8c20f4f67eb229ad66a',1,'Document::Document()'],['../class_document.html#a4399bbc9420b5e5c269e9d38be5d4810',1,'Document::Document(const std::string &amp;doc_fp)']]],
  ['documentindexer',['DocumentIndexer',['../class_document_indexer.html#a44f3c39ee50c32c0226fe98a66f71d07',1,'DocumentIndexer']]]
];
